print ('Adding Integers with Videlle.')

num1 = input("Type in a number:")
num2 = input("Type in a number:")

result = int(num1)+int(num2)
print (result)