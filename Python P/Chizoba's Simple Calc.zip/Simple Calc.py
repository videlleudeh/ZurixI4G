print ("Videlle's CLI Calculator")

print (" ")

num1 = float(input("Enter a number:"))
opr = input("+ - / % OR *:")
num2 = float(input("Enter another number:"))


print (" ")

if opr == "+":
    print (num1 + num2)
elif opr == "-":
    print (num1 - num2)
elif opr == "/":
    print (num1 / num2)
elif opr == "%":
    print (num1 % num2)
elif opr == "*":
    print (num1 * num2)
else: 
    print("Syntax error")
